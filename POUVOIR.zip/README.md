# Expert Influence Group - PRO SaaS

## Setup

### Backend
cd backend
npm install
node server.js

### Frontend
cd frontend
npm install
npm run dev

## Deploy
- Frontend: Vercel
- Backend: Render
- DB: MongoDB Atlas
