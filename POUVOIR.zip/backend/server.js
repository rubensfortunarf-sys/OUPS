require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Stripe = require('stripe');
const OpenAI = require('openai');
const nodemailer = require('nodemailer');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI);

const User = mongoose.model('User',{
 email:String,
 password:String,
 plan:String,
 usage:{type:Number,default:0}
});

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const openai = new OpenAI({apiKey:process.env.OPENAI_API_KEY});

// AUTH
app.post('/signup', async(req,res)=>{
 const {email,password}=req.body;
 const hashed = await bcrypt.hash(password,10);
 const user = await User.create({email,password:hashed});
 const token = jwt.sign({id:user._id},process.env.JWT_SECRET);
 res.json({token});
});

app.post('/login', async(req,res)=>{
 const {email,password}=req.body;
 const user = await User.findOne({email});
 const valid = await bcrypt.compare(password,user.password);
 if(!valid) return res.status(401).send("Invalid");
 const token = jwt.sign({id:user._id},process.env.JWT_SECRET);
 res.json({token});
});

// DASHBOARD
app.get('/dashboard', async(req,res)=>{
 res.json({users:100,revenue:5000});
});

// STRIPE SUB
app.post('/subscribe', async(req,res)=>{
 const {email,plan}=req.body;

 const prices={
  starter:process.env.STRIPE_STARTER,
  growth:process.env.STRIPE_GROWTH,
  enterprise:process.env.STRIPE_ENTERPRISE
 };

 const session = await stripe.checkout.sessions.create({
  mode:'subscription',
  line_items:[{price:prices[plan],quantity:1}],
  success_url:'http://localhost:3000',
  cancel_url:'http://localhost:3000'
 });

 res.json({url:session.url});
});

// AI CLOSER
app.post('/ai-close', async(req,res)=>{
 const {message}=req.body;

 const completion = await openai.chat.completions.create({
  model:"gpt-4o-mini",
  messages:[
   {role:"system",content:"You are an AI sales closer."},
   {role:"user",content:message}
  ]
 });

 res.json({reply:completion.choices[0].message.content});
});

// EMAIL
const transporter = nodemailer.createTransport({
 service:'gmail',
 auth:{user:process.env.EMAIL,pass:process.env.EMAIL_PASS}
});

app.post('/email', async(req,res)=>{
 await transporter.sendMail({
  from:process.env.EMAIL,
  to:req.body.email,
  subject:"Book a Call",
  text:"Schedule here: https://calendly.com"
 });
 res.send("sent");
});

app.listen(5000,()=>console.log("PRO SaaS running"));
