import { useState } from "react";
import axios from "axios";

export default function App() {
  const [email, setEmail] = useState("");

  const subscribe = async (plan) => {
    const res = await axios.post("http://localhost:5000/subscribe", { email, plan });
    window.location.href = res.data.url;
  };

  return (
    <div style={{background:"black",color:"white",minHeight:"100vh",padding:"40px"}}>
      <h1 style={{color:"#00ff99"}}>Expert Influence Group</h1>
      <p>AI Systems That Scale Businesses</p>

      <input placeholder="Enter email" onChange={(e)=>setEmail(e.target.value)} />

      <div style={{marginTop:"30px"}}>
        <button onClick={()=>subscribe("starter")}>Starter $99</button>
        <button onClick={()=>subscribe("growth")}>Growth $299</button>
        <button onClick={()=>subscribe("enterprise")}>Enterprise $999</button>
      </div>

      <Chatbot />
    </div>
  );
}

function Chatbot(){
  const [msg,setMsg]=useState("");
  const [chat,setChat]=useState([]);

  const send = async ()=>{
    const res = await fetch("http://localhost:5000/ai-close",{
      method:"POST",
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({message:msg})
    });
    const data = await res.json();
    setChat([...chat,{u:msg},{ai:data.reply}]);
    setMsg("");
  }

  return(
    <div style={{marginTop:"40px"}}>
      <h3>AI Assistant</h3>
      {chat.map((c,i)=><p key={i}>{c.u||c.ai}</p>)}
      <input value={msg} onChange={(e)=>setMsg(e.target.value)} />
      <button onClick={send}>Send</button>
    </div>
  )
}
